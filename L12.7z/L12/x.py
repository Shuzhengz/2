piece = "false"
score = 0
class Ro:
	def __init__(self, pos, armp):
		self.armp = armp
		self.pos = pos
	def move(self, dist):
		self.pos += dist
	def claw(self, dist):
		self.armp += dist
Rob = Ro(0, 0)