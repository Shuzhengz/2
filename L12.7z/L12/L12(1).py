import x as one
import y as two
one
two