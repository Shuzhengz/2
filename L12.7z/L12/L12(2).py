from math import sqrt
x = []
for num in str(123456789098765):
	y = sqrt(int(num))
	x.append(y)
print(x)